@extends("layout") @section("main-content")

    <header id="index">
        <!-- <h3>My name is shrinit goyal</h3>
        <div class="main_content">
            <span>Hey, There!</span>
            <span id="type-text">...</span>
            <span class="blinking-cursor">_</span>
        </div> -->
        <div class="container-xl">
            <div class="row">
                <div class="col-lg-6">
                    <div class="side_image">
                        <img src="public/my_image.jpg" alt="profile pic">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="main_content">
                        <span>Hey, There!</span>
                        <span id="type-text">...</span>
                        <span class="blinking-cursor">_</span>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <section class="afterheader" id="aboutme">
        <h1 class="ml11"><span class="text-wrapper"><span class="line line1"></span><span class="letters">Something About Me</span></span></h1>
        <div class="row">
            <div class="col-lg-4 col-12">
                <img src="public/my_image.jpg" alt="my_profile_image" class="w3-hover-grayscale">
                <p style="font-size: 1.5em; margin-top: 20px;">Ongoing graduation with a degree of B.TECH in Computer Science stream, i am a hard-working, goal-oreinted, focused person. I have participated in various events and hackathons, holds the experience of about 2 years in Web Development Technology</span></span><p>
            </div>
            <div class="col-lg-8 col-12">
                <h3>Technology Stack</h5>
                <div class="row">
                    <div class="col-lg-6 col-6 tech_heading">
                        <h4>SKILLS</h4>
                    </div>
                    <div class="col-lg-6 col-6 competency_level_text">
                        <h4>Competency Level</h4>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6 col-6" style="padding-left: 13vw;">
                        <h4>HTML</h4>
                    </div>
                    <div class="col-lg-6 col-6" style="padding-right: 19vw;">
                        <i class="fa fa-star" style="margin-top: 15px;"></i>
                        &nbsp<i class="fa fa-star"></i>
                        &nbsp<i class="fa fa-star"></i>
                        &nbsp<i class="fa fa-star"></i>
                        &nbsp<i class="fa fa-star-half"></i>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6 col-6" style="padding-left: 13vw;">
                        <h4>CSS</h4>
                    </div>
                    <div class="col-lg-6 col-6" style="padding-right: 19vw;">
                        <i class="fa fa-star" style="margin-top: 15px;"></i>
                        &nbsp<i class="fa fa-star"></i>
                        &nbsp<i class="fa fa-star"></i>
                        &nbsp<i class="fa fa-star"></i>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6 col-6" style="padding-left: 13vw;">
                        <h4>BOOTSTRAP</h4>
                    </div>
                    <div class="col-lg-6 col-6" style="padding-right: 19vw;">
                        <i class="fa fa-star" style="margin-top: 15px;"></i>
                        &nbsp<i class="fa fa-star"></i>
                        &nbsp<i class="fa fa-star"></i>
                        &nbsp<i class="fa fa-star"></i>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6 col-6" style="padding-left: 13vw;">
                        <h4>PHP</h4>
                    </div>
                    <div class="col-lg-6 col-6" style="padding-right: 19vw;">
                        <i class="fa fa-star" style="margin-top: 15px;"></i>
                        &nbsp<i class="fa fa-star"></i>
                        &nbsp<i class="fa fa-star"></i>
                        &nbsp<i class="fa fa-star"></i>
                        &nbsp<i class="fa fa-star-half"></i>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6 col-6" style="padding-left: 13vw;">
                        <h4>MYSQL</h4>
                    </div>
                    <div class="col-lg-6 col-6" style="padding-right: 19vw;">
                        <i class="fa fa-star" style="margin-top: 15px;"></i>
                        &nbsp<i class="fa fa-star"></i>
                        &nbsp<i class="fa fa-star"></i>
                        &nbsp<i class="fa fa-star-half"></i>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6 col-6" style="padding-left: 13vw;">
                        <h4>AJAX</h4>
                    </div>
                    <div class="col-lg-6 col-6" style="padding-right: 19vw;">
                        <i class="fa fa-star" style="margin-top: 15px;"></i>
                        &nbsp<i class="fa fa-star"></i>
                        &nbsp<i class="fa fa-star"></i>
                        &nbsp<i class="fa fa-star-half"></i>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6 col-6" style="padding-left: 13vw;">
                        <h4>JQUERY</h4>
                    </div>
                    <div class="col-lg-6 col-6" style="padding-right: 19vw;">
                        <i class="fa fa-star" style="margin-top: 15px;"></i>
                        &nbsp<i class="fa fa-star"></i>
                        &nbsp<i class="fa fa-star"></i>
                        &nbsp<i class="fa fa-star-half"></i>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6 col-6" style="padding-left: 13vw;">
                        <h4>LARAVEL</h4>
                    </div>
                    <div class="col-lg-6 col-6" style="padding-right: 19vw;">
                        <i class="fa fa-star" style="margin-top: 15px;"></i>
                        &nbsp<i class="fa fa-star"></i>
                        &nbsp<i class="fa fa-star"></i>
                        &nbsp<i class="fa fa-star"></i>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6 col-6" style="padding-left: 13vw;">
                        <h4>C PROGRAMMING</h4>
                    </div>
                    <div class="col-lg-6 col-6" style="padding-right: 19vw;">
                        <i class="fa fa-star" style="margin-top: 15px;"></i>
                        &nbsp<i class="fa fa-star"></i>
                        &nbsp<i class="fa fa-star"></i>
                        &nbsp<i class="fa fa-star"></i>
                        &nbsp<i class="fa fa-star-half"></i>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6 col-6" style="padding-left: 13vw;">
                        <h4>OPENCV PYTHON</h4>
                    </div>
                    <div class="col-lg-6 col-6" style="padding-right: 19vw;">
                        <i class="fa fa-star" style="margin-top: 15px;"></i>
                        &nbsp<i class="fa fa-star"></i>
                        &nbsp<i class="fa fa-star"></i>
                        &nbsp<i class="fa fa-star"></i>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="education">
        <h1 class="ml16" style="color:#fff;">Education</h1>
        <div class="row college">
            <div class="col-lg-6 col-6">
                <h3>Bachelor of Technology</h3>
                <br>
                <h4>University Departments of Rajasthan Technical University</h4>
                <h5>Kota, Rajasthan</h5>
            </div>
            <div class="col-lg-6 col-6" style="margin-top: 70px;">
                <h4 class="year">2018-2022</h4>
                <h4>8.03 GPA</h4>
            </div>
        </div>
        <div class="row college">
            <div class="col-lg-6 col-6">
                <h3>Senior Secondary Education</h3>    
                <br>
                <h4>Siwaich Kendriya Senior Secondary School</h4>
                <h5>Bharatpur, Rajasthan</h5>
            </div>
            <div class="col-lg-6 col-6" style="margin-top: 70px;">
                <h4 class="year">2017-2028</h4>
                <h4>83.80%</h4>
            </div>
        </div>
        <div class="row college">
            <div class="col-lg-6 col-6">
                <h3>Secondary Education</h3>
                <br>
                <h4>Sony Academy Senior Secondary School</h4>
                <h5>Bharatpur, Rajasthan</h5>
            </div>
            <div class="col-lg-6 col-6" style="margin-top: 70px;">
                <h4 class="year">2015-2016</h4>
                <h4>88.50%</h4>
            </div>
        </div>
    </section>

    <section id="resume">
        <h1 class="ml14">
            <span class="text-wrapper">
                <span class="letters">Have a look on my resume</span>
                <span class="line"></span>
            </span>
        </h1>
        <div class="row" style="width: 80%; margin-left:auto; margin-right:auto;">
            <div class="col-lg-6">
                <iframe src="https://drive.google.com/file/d/1gKY_G-heFuriWL3j4B8KOMte-jwmbX5B/preview" id="iframe" style="height: 35vw; width: 40vw;"></iframe>
            </div>
            <div class="col-lg-6" id="resume_button">
                <div id="button_background">
                    <h3>Download from here</h3>
                    <a href="public/shrinit resume.docx"><button class="btn btn-primary" >Download</button></a>
                </div>
            </div>
        </div>
    </section>

    <section id="experience">
        <h1 class="ml1">
            <span class="text-wrapper">
                <span class="line line1"></span>
                <span class="letters">Some of my work experiences</span>
                <span class="line line2"></span>
            </span>
        </h1>
        <div class="row">
            <div class="col-lg-6 col-6">
                <img src="public/download.jpg">
                <h3>PHP Development Intern</h3>
                <h4>Rovae Incorporation</h4>
                <h5>Pune, Mahararshtra</h5>
                <p>August, 2020 - November, 2020</p>
            </div>
            <div class="col-lg-6 col-6">
                <h6>My work was to integrate the backend in the application. I get to know about how work is done in an professional industry. I learned a lot of new techs include Laravel, SASS, Yajra Datatables, AJAX and much more thing on a advanced level.</h6>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-6 col-6">
            <img src="public/cryptics.jpg">
                <h3>Full Stack Web Development Intern</h3>
                <h4>Cryptics India Education</h4>
                <h5>Kota, Rajasthan</h5>
                <p>February, 2019 - April, 2019</p>
            </div>
            <div class="col-lg-6 col-6">
                <h6>I was handling both frontend and backend part. I learned how to work on live server and to deploy project on the live server</h6>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-6 col-6">
            <img src="public/thar.jpg">
                <h3>Robo-Soccer Event Coordinator</h3>
                <h4>THAR'20, Annual Techfest of RTU Kota</h4>
                <h5>Kota, Rajasthan</h5>
                <p>February 28, 2019 - March 1, 2019</p>
            </div>
            <div class="col-lg-6 col-6">
                <h6>I was the Event Coordinator of ROBOSOCCER, soccer played by the bots that were mechanically and electronically designed by the teams. I got a lot of experience how to lead the team and how to handle the circumstances at the instant and many new tactics which can only be understood through such roles.</h6>
            </div>
        </div>
    </section>

    <section id="projects">
        <h1 class="ml7">
            <span class="text-wrapper">
                <span class="letters">Projects</span>
            </span>
        </h1>
        <div class="row" style="width: 90%; margin-left:auto; margin-right:auto;">
            <div class="col-lg-6 col-6" id="project1">
                <img src="public/healthseva.png">
                <h3>HealthSeva</h3>
                <h4><i class="fa fa-arrow-right"></i>&nbsp1st runner-up WebHack Hackathon RTU</h4>
                <h5><i class="fa fa-arrow-right"></i>&nbspGet Urgent availability of Blood and Plasma Donors along with Hospital and Doctor info on the Web portal as well as through simpe text messages</h5>
                <h6><i class="fa fa-arrow-right"></i>&nbspTech Used:- Ozeki NG SMS Gateway, PHP, MYSQL, BOOTSTRAP, HTML, CSS</h6>
            </div>
            <div class="col-lg-6 col-6" id="project2">
                <img src="public/roboclubrtu.jpg">
                <h3>roboclubrtu.com</h3>
                <h4><i class="fa fa-arrow-right"></i>&nbspRobotics Club RTU Kota</h4>
                <h5><i class="fa fa-arrow-right"></i>&nbspMultiple login system, integrated with Real-time Chat application where user can add posts, comment on them, send direct messages to anyone, show real-time availability of users present.</h5>
                <h6><i class="fa fa-arrow-right"></i>&nbspTech Used:- PHP, MYSQL, File-Handling, BOOTSTRAP, HTML, CSS</h6>
            </div>
        </div>
        <div class="row" style="width: 90%; margin-left:auto; margin-right:auto; margin-top:50px;">
            <div class="col-lg-6 col-6" id="project3">
                <img src="public/smart_parking.png">
                <h3>Smart Parking System</h3>
                <h4><i class="fa fa-arrow-right"></i>&nbspSmart way to find parking slots</h4>
                <h5><i class="fa fa-arrow-right"></i>&nbspFinding Parking is a very time consuming process so a smart way has been developed through which all the available parking slots will be shown on the web portal just by entering the pincode of the area.</h5>
                <h6><i class="fa fa-arrow-right"></i>&nbspTech Used:- ESP8266(IoT, for data communication between server and parking slot), PHP, MYSQL, Javascript, BOOTSTRAP, HTML, CSS</h6>
            </div>
            <div class="col-lg-6 col-6" id="project4">
                <img src="public/khad.png">
                <h3>Khad Selector</h3>
                <h4><i class="fa fa-arrow-right"></i>&nbspFirst patent project</h4>
                <h5><i class="fa fa-arrow-right"></i>&nbspPredicting the amount of fertilizers to be used in the field with the help of N, P, K values obtaining after the analysis of image of the soil solution, also predicting the profit-loss statement of the user constituting the total expenditure and total income.</h5>
                <h6><i class="fa fa-arrow-right"></i>&nbspTech Used:- OpenCV, Python, PHP, MYSQL, Javascript, BOOTSTRAP, HTML, CSS</h6>
            </div>
        </div>
    </section>

    @stop