@extends("layout") @section("main-content")

<div class="container-xl">
    <div class="row">
        <div class="col-lg-6">
            <div class="main_content">
                <span>Hey, There!</span>
                <span id="type-text">...</span>
                <span class="blinking-cursor">_</span>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="side_image">
                <img src="public/my_image.jpg" alt="profile pic">
            </div>
        </div>
    </div>
</div>

<p id="aboutme">Here is something about me</p>

<div class="container-fluid" id="about">

    <div class="row">
    
        <div class="col-xl-6 col-12">

            <div class="row">

                <div class="col-12">

                    <img src="{{asset('public/my_image_2.jpeg')}}" style="height: 10em; width: 10em; border: 5px solid white; border-radius: 100%; display: block; margin-left: auto; margin-right: auto; ">

                </div>

                <div class="col-12">
            
                    <p>Ongoing graduation with a degree of B.TECH in Computer Science stream, i am a hard-working, goal-oreinted, focused person. I have participated in various events and hackathons, holds the experience of about 2 years in Web Development Technology</p>

                </div>

            </div>
        
        </div>

        <div class="col-xl-6 col-12">
        
            <h5 style="font-family: 'Rubik', sans-serif;">My Tech Stack</h5> <hr>
                <div class="row">
                    <div class="col-xl-6 col-6">
                        <h6>Skills</h6>
                    </div>
                    <div class="col-xl-6 col-6">
                        <h6>Difficuilty Level</h6>
                    </div>
                </div>
                <div class="row" style="margin-top: 20px;">
                    <div class="col-xl-6 col-6">
                        <p style="float: left;">HTML</p>
                    </div>
                    <div class="col-xl-6 col-6">
                        &nbsp<i class="fa fa-star"></i>
                                                  &nbsp<i class="fa fa-star"></i>
                                                  &nbsp<i class="fa fa-star"></i>
                                                  &nbsp<i class="fa fa-star"></i>
                                                  &nbsp<i class="fa fa-star-half"></i>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-6 col-6">
                        <p style="float: left;">CSS</p>
                    </div>
                    <div class="col-xl-6 col-6">
                        &nbsp<i class="fa fa-star"></i>
                                                  &nbsp<i class="fa fa-star"></i>
                                                  &nbsp<i class="fa fa-star"></i>
                                                  &nbsp<i class="fa fa-star"></i>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-6 col-6">
                        <p style="float: left;">BOOTSTRAP</p>
                    </div>
                    <div class="col-xl-6 col-6">
                        &nbsp<i class="fa fa-star"></i>
                                                  &nbsp<i class="fa fa-star"></i>
                                                  &nbsp<i class="fa fa-star"></i>
                                                  &nbsp<i class="fa fa-star"></i>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-6 col-6">
                        <p style="float: left;">PHP</p>
                    </div>
                    <div class="col-xl-6 col-6">
                        &nbsp<i class="fa fa-star"></i>
                                                  &nbsp<i class="fa fa-star"></i>
                                                  &nbsp<i class="fa fa-star"></i>
                                                  &nbsp<i class="fa fa-star"></i>
                                                  &nbsp<i class="fa fa-star-half"></i>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-6 col-6">
                        <p style="float: left;">MySQL</p>
                    </div>
                    <div class="col-xl-6 col-6">
                        &nbsp<i class="fa fa-star"></i>
                                                  &nbsp<i class="fa fa-star"></i>
                                                  &nbsp<i class="fa fa-star"></i>
                                                  &nbsp<i class="fa fa-star-half"></i>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-6 col-6">
                        <p style="float: left;">AJAX</p>
                    </div>
                    <div class="col-xl-6 col-6">
                        &nbsp<i class="fa fa-star"></i>
                                                  &nbsp<i class="fa fa-star"></i>
                                                  &nbsp<i class="fa fa-star"></i>
                                                  &nbsp<i class="fa fa-star-half"></i>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-6 col-6">
                        <p style="float: left;">LARAVEL</p>
                    </div>
                    <div class="col-xl-6 col-6">
                        &nbsp<i class="fa fa-star"></i>
                                                  &nbsp<i class="fa fa-star"></i>
                                                  &nbsp<i class="fa fa-star"></i>
                                                  &nbsp<i class="fa fa-star"></i>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-6 col-6">
                        <p style="float: left;">C Programming</p>
                    </div>
                    <div class="col-xl-6 col-6">
                        &nbsp<i class="fa fa-star"></i>
                                                  &nbsp<i class="fa fa-star"></i>
                                                  &nbsp<i class="fa fa-star"></i>
                                                  &nbsp<i class="fa fa-star"></i>
                                                  &nbsp<i class="fa fa-star-half"></i>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-6 col-6">
                        <p style="float: left;">OpenCV PYTHON</p>
                    </div>
                    <div class="col-xl-6 col-6">
                        &nbsp<i class="fa fa-star"></i>
                                                  &nbsp<i class="fa fa-star"></i>
                                                  &nbsp<i class="fa fa-star"></i>
                                                  &nbsp<i class="fa fa-star"></i>
                    </div>
                </div>
        
        </div>
    
    </div>

</div>


<h3 id="edu" style="text-align: center; font-family: 'Rubik', sans-serif; font-size: 1.5em;">Education</h3><hr>

<div class="container" id="education">
    <div class="row" style="margin-top: 40px;">
        <div class="col-xl-6 col-6 headings">
            <h5>Bachelor of Technology</h5><hr><br>
            <h6>Rajasthan Technical University</h6>
            <p>Kota, Rajasthan</p>
        </div>
        <div class="col-xl-6 col-6 data">
            <h6 style="margin-top: 90px;">2018-2022</h6>
            <p>8.03 GPA</p>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an .</p>
        </div>
    </div>

    <div class="row" style="margin-top: 40px;">
        <div class="col-xl-6 col-6 headings">
            <h5 style="color: #5dc7c3;">Senior Secondary Education</h5><hr><br>
            <h6>Siwaich Kendriya Sr. Sec. School</h6>
            <p>Bharatpur, Rajasthan</p>
        </div>
        <div class="col-xl-6 col-6 data">
            <h6 style="margin-top: 90px;">2017-2018</h6>
            <p>84.80%</p>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown .</p>
        </div>
    </div>

    <div class="row">
        <div class="col-xl-6 col-6 headings">
            <h5 style="color: #5dc7c3;">Secondary Education</h5><hr><br>
            <h6>Sony Academy Sr. Sec. School</h6>
            <p>Bharatpur, Rajasthan</p>
        </div>
        <div class="col-xl-6 col-6 data">
            <h6 style="margin-top: 90px;">2015-2016</h6>
            <p>88.50%</p>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an.</p>
        </div>
    </div>

</div>

<h3 style="text-align: center; margin-bottom:40px; margin-top: 400px; font-family: 'Rubik', sans-serif; font-size: 1.5em;" id="resume">Have a look on my Resume</h3><hr>

<div class="container" id="show_resume">

    <div class="row" style="margin-top: 40px;">
        <div class="col-xl-6">
            <h3 style=" font-family: 'Dancing Script', cursive; font-size: 1em;"> You are just a click away from my resume &nbsp <i class="fa fa-arrow-right"></i></h3>
        </div>
        <div class="col-xl-6">
            <a href="{{asset('shrinit resume.docx')}}" download>
                <button type="button" class="btn btn-primary click_resume">Download Here</button>
            </a>
        </div>
    </div>

</div>

<h3 style="text-align: center; margin-bottom: 60px; margin-top: 150px; font-family: 'Rubik', sans-serif; font-size: 1em;" id="experience">Work Experience</h3><hr>

<div class="container" id="work">

    <div class="row">

        <div class="col-xl-6">

            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">THAR'20</h5>
                    <h6 class="card-subtitle mb-2 text-muted">Annual Techfest of Rajasthan Technical University, Kota</h6>
                    <p class="card-text">Co-ordinator, ROBO-SOCCER</p>
                    <br><br>
                    <p class="card-text">FEB 28, 2020 - MAR 1, 2020</p>
                    <p></p>
                </div>
            </div>

        </div>

        <div class="col-xl-6">
        
            <p>hello world</p>

        </div>

    </div>

    <div class="row" style="margin-top: 50px;">

        <div class="col-xl-6">
            
            <p>hello world</p>

        </div>

        <div class="col-xl-6">

            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Cryptics India Education</h5>
                    <h6 class="card-subtitle mb-2 text-muted">Kota, Rajasthan</h6>
                    <p class="card-text">Full Stack Web Development Intern</p>
                    <br><br>
                    <p class="card-text">FEB'20 - APR'20</p>
                </div>
            </div>

        </div>

    </div>

    <div class="row" style=" margin-top: 50px;">

        <div class="col-xl-6">

            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Rovae Incorporation</h5>
                    <h6 class="card-subtitle mb-2 text-muted">Pune, Maharashtra</h6>
                    <p class="card-text">PHP Development Intern</p>
                    <br><br>
                    <p class="card-text">AUG'20 - NOV'20</p>
                </div>
            </div>

        </div>

        <div class="col-xl-6">
        
            <p>hello world</p>

        </div>

    </div>

</div>

<h4 style="text-align: center; margin-bottom:50px; margin-top: 800px; font-family: 'Rubik', sans-serif; font-size: 1em;" id="projects">Some of my cool projects</h4><hr>

<div class="container-fluid" id="show_projects">

    <div class="row">

        <div class="col-xl-3 col-6">
        
            <div class="card" style="width: 20rem; margin: auto;">
                <img class="card-img-top" src="{{asset('public/my_image_2.jpeg')}}" alt="Card image cap" style="width: 100%; height: 300px;">
                <div class="card-body">
                    <h5 class="card-title">Card title</h5>
                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                </div>
            </div>
        
        </div>

        <div class="col-xl-3 col-6">
        
            <div class="card" style="width: 20rem; margin: auto;">
                <img class="card-img-top" src="{{asset('public/my_image_2.jpeg')}}" alt="Card image cap" style="width: 100%; height: 300px;">
                <div class="card-body">
                    <h5 class="card-title">Card title</h5>
                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                </div>
            </div>
        
        </div>

        <div class="col-xl-3 col-6">
        
            <div class="card" style="width: 20rem; margin: auto;">
                <img class="card-img-top" src="{{asset('public/my_image_2.jpeg')}}" alt="Card image cap" style="width: 100%; height: 300px;">
                <div class="card-body">
                    <h5 class="card-title">Card title</h5>
                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                </div>
            </div>
        
        </div>

        <div class="col-xl-3 col-6">
        
            <div class="card" style="width: 20rem; margin: auto;">
                <img class="card-img-top" src="{{asset('public/my_image_2.jpeg')}}" alt="Card image cap" style="width: 100%; height: 300px;">
                <div class="card-body">
                    <h5 class="card-title">Card title</h5>
                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                </div>
            </div>
        
        </div>

    </div>

</div>

<h4 style="text-align: center; margin-bottom:40px; margin-top: 100px; font-family: 'Rubik', sans-serif;">Let's Get Connected...</h4> <hr>

<div class="container-fluid" id="contact">

    <div class="row form">

        <div class="col-xl-6">

            <h2 style="text-align: center; margin-bottom: 30px;">Please fill out this form</h2>
        
            <form>
                <div class="form-group">
                    <label for="exampleInputEmail1">Name</label>
                    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Email address</label>
                    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Mobile Number</label>
                    <input type="text" class="form-control" id="exampleInputPassword1" required>
                </div>
                <div class="form-group">
                    <label for="exampleFormControlTextarea1">Feedback/Suggestion</label>
                    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Send Message</button>
            </form>

        </div>

        <div class="col-xl-6">

            <h3>You can also find me here: </h3>
        
            <p><i class="fa fa-google-plus"></i>&nbsp&nbspshrinitg@gmail.com
            <br>
            <i class="fa fa-phone"></i>&nbsp&nbsp&nbsp+91 7737805106
            <br><br>
            <!-- <i class="fa fa-github"></i>&nbsp&nbsp
            <br>
            <i class="fa fa-facebook-official"></i>&nbsp&nbsp
            <br>
            <i class="fa fa-google-plus"></i>&nbsp&nbspshrinitg@gmail.com
            -->
            <a href="https://github.com/shrinitg"><i class="fa fa-github"></i></a>
            <a href="https://www.facebook.com/shrinit.goyal/"><i class="fa fa-facebook-official"></i></a>
            <a href="https://www.linkedin.com/in/shrinit-goyal-86222716a/"><i class="fa fa-linkedin-square"></i></a>
            <a href="https://www.instagram.com/gshrinit/?hl=en"><i class="fa fa-instagram"></i></a>
            <a href="https://twitter.com/shrinitg"><i class="fa fa-twitter-square"></i></a>
            <a href="https://stackoverflow.com/users/13663565/shrinit-goyal"><i class="fa fa-stack-overflow"></i></a>
            </p> 
        
        </div>
    
    </div>

    <p style="text-align: center; margin-bottom: -10px;">Copyright @Shrinit Goyal <br> Made with <a href="https://getbootstrap.com/">Bootstrap</a></p>

</div>

@stop