<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,height=device-height,initial-scale=1.0"/>

    <!-- main css -->
    <link rel="stylesheet" type="text/css" href="public/css/main.css">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" type="text/css" href="public/css/main.css">
    <script async src="https://jsfiddle.net/eLwex993/2/embed/"></script>

    <title>Shrinit Goyal :: My Portfolio</title>

  </head>
  <body>

    <!-- <nav class="navbar navbar-expand-lg navbar-dark navbar-fixed-top" id="navbar">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
                <a class="nav-link" href="/my_portfolio">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#aboutme">About</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#education">Education</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#resume">Resume</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#experience">Work Experience</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#projects">Projects</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#contact">Contact</a>
            </li>
            </ul>
        </div>
    </nav> -->

    <?php echo $__env->yieldContent('main-content'); ?>

    <!-- Optional JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/2.0.2/anime.min.js"></script>
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>

    <script>
            // Wrap every letter in a span
            var textWrapper = document.querySelector('.ml11 .letters');
            textWrapper.innerHTML = textWrapper.textContent.replace(/([^\x00-\x80]|\w)/g, "<span class='letter'>$&</span>");

            anime.timeline({loop: true})
            .add({
                targets: '.ml11 .line',
                scaleY: [0,1],
                opacity: [0.5,1],
                easing: "easeOutExpo",
                duration: 700
            })
            .add({
                targets: '.ml11 .line',
                translateX: [0, document.querySelector('.ml11 .letters').getBoundingClientRect().width + 10],
                easing: "easeOutExpo",
                duration: 700,
                delay: 100
            }).add({
                targets: '.ml11 .letter',
                opacity: [0,1],
                easing: "easeOutExpo",
                duration: 600,
                offset: '-=775',
                delay: (el, i) => 34 * (i+1)
            }).add({
                targets: '.ml11',
                opacity: 0,
                duration: 1000,
                easing: "easeOutExpo",
                delay: 1000
            });

            // Wrap every letter in a span
            var textWrapper = document.querySelector('.ml16');
            textWrapper.innerHTML = textWrapper.textContent.replace(/\S/g, "<span class='letter'>$&</span>");

            anime.timeline({loop: true})
            .add({
                targets: '.ml16 .letter',
                translateY: [-100,0],
                easing: "easeOutExpo",
                duration: 1000,
                delay: (el, i) => 30 * i
            }).add({
                targets: '.ml16',
                opacity: 0,
                duration: 1000,
                easing: "easeOutExpo",
                delay: 1000
            });

            
            // Wrap every letter in a span
            var textWrapper = document.querySelector('.ml14 .letters');
            textWrapper.innerHTML = textWrapper.textContent.replace(/\S/g, "<span class='letter'>$&</span>");

            anime.timeline({loop: true})
            .add({
                targets: '.ml14 .line',
                scaleX: [0,1],
                opacity: [0.5,1],
                easing: "easeInOutExpo",
                duration: 900
            }).add({
                targets: '.ml14 .letter',
                opacity: [0,1],
                translateX: [40,0],
                translateZ: 0,
                scaleX: [0.3, 1],
                easing: "easeOutExpo",
                duration: 800,
                offset: '-=600',
                delay: (el, i) => 150 + 25 * i
            }).add({
                targets: '.ml14',
                opacity: 0,
                duration: 1000,
                easing: "easeOutExpo",
                delay: 1000
            });

            // Wrap every letter in a span
            var textWrapper = document.querySelector('.ml1 .letters');
            textWrapper.innerHTML = textWrapper.textContent.replace(/\S/g, "<span class='letter'>$&</span>");

            anime.timeline({loop: true})
            .add({
                targets: '.ml1 .letter',
                scale: [0.3,1],
                opacity: [0,1],
                translateZ: 0,
                easing: "easeOutExpo",
                duration: 600,
                delay: (el, i) => 70 * (i+1)
            }).add({
                targets: '.ml1 .line',
                scaleX: [0,1],
                opacity: [0.5,1],
                easing: "easeOutExpo",
                duration: 700,
                offset: '-=875',
                delay: (el, i, l) => 80 * (l - i)
            }).add({
                targets: '.ml1',
                opacity: 0,
                duration: 1000,
                easing: "easeOutExpo",
                delay: 1000
            });

            // Wrap every letter in a span
            var textWrapper = document.querySelector('.ml7 .letters');
            textWrapper.innerHTML = textWrapper.textContent.replace(/\S/g, "<span class='letter'>$&</span>");

            anime.timeline({loop: true})
            .add({
                targets: '.ml7 .letter',
                translateY: ["1.1em", 0],
                translateX: ["0.55em", 0],
                translateZ: 0,
                rotateZ: [180, 0],
                duration: 750,
                easing: "easeOutExpo",
                delay: (el, i) => 50 * i
            }).add({
                targets: '.ml7',
                opacity: 0,
                duration: 1000,
                easing: "easeOutExpo",
                delay: 1000
            });

        //     var elem = document.getElementById("navbar");
        //     var width = $(window).width();

        //     if(width >= 1006)
        //     {
        //         var pos = 0;
        //         var id = setInterval(frame, 0.1);
        //         function frame() {
        //             if (pos == 1520) {
        //             clearInterval(id);
        //             } else {
        //             pos++; 
        //             elem.style.left = pos + "px"; 
        //             }
        //         }
        //     }
        //     else{
        //         elem.style.left = "1520px";
        //     }
        // }

        function init () {

        wait(1000).then(() => {
        clearText()
        typeText(' ').then(typeLoop)
        })

        function typeLoop() {
        typeText('I am WEB DEVELOPER!')
            .then(() => wait(2000))
            .then(() => removeText('WEB DEVELOPER!'))
            .then(() => typeText('CODER!'))
            .then(() => wait(2000))
            .then(() => removeText('CODER!'))
            .then(() => typeText('CHEF!'))
            .then(() => wait(2000))
            .then(() => removeText('WEB DEVELOPER!'))
            .then(typeLoop)
        }

        }


        // Source code 🚩

        const elementNode = document.getElementById('type-text')
        let text = ''

        function updateNode () {
        elementNode.innerText = text
        }

        function pushCharacter (character) {
        text += character
        updateNode()
        }

        function popCharacter () {
        text = text.slice(0, text.length -1)
        updateNode()
        }

        function clearText () {
        text = ''
        updateNode()
        }


        function wait (time) {
        if (time === undefined) {
        const randomMsInterval = 100 * Math.random()
        time = randomMsInterval < 50 ? 10 : randomMsInterval
        }

        return new Promise(resolve => {
        setTimeout(() => {
            requestAnimationFrame(resolve)
        }, time)
        })
        }

        function typeCharacter (character) {
        return new Promise(resolve => {
        pushCharacter(character)
        wait().then(resolve)
        })
        }

        function removeCharacter () {
        return new Promise(resolve => {
        popCharacter()
        wait().then(resolve)
        })
        }

        function typeText (text) {
        return new Promise(resolve => {
        
        function type ([ character, ...text ]) {
            typeCharacter(character)
            .then(() => {
                if (text.length) type(text)
                else resolve()
            })
        }
        
        type(text)
        })
        }

        function removeText ({ length:amount }) {
        return new Promise(resolve => {
        
        function remove (count) {
            removeCharacter()
            .then(() => {
                if (count > 1) remove(count - 1)
                else resolve()
            })
        }
        
        remove(amount)
        })
        }


        init()

    </script>

<a href="#index" id="navigate_to_top"><button type="button" class="btn"><i class="fa fa-arrow-circle-up"></i></button></a>

  </body>
</html><?php /**PATH C:\xampp\htdocs\my_portfolio\resources\views/layout.blade.php ENDPATH**/ ?>